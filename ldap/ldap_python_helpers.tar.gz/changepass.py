#!/usr/bin/python

import os
import sys
import string

print ('This program will assist in changing a users password, it does not prompt for the old password' + '\n')
username = raw_input('What is the users name? ')
print ('\n')
userpass = 
