#!/bin/bash

fs="/Users/car"
hostname="laptop"

bkupdir="/Backups"
bkupdir="."

rmtdir="/nersc/projects/ccse/$hostname"

errlog="-d $bkupdir/errorlog/ncftpput.errlog.diff"
hfspaxarg="-wx cpio"
ncftparg="$errlog -f $bkupdir/afiletest -c"

for fs in $fs; do
    fixedfs=$(echo $fs | sed -e 's;/;_;g')
    daystr=$(date +"%y%m%d%H%M") 
    fbdate=$(ls -tC1 $bkupdir/timestamps/TimeStamp-for-$fixedfs-* | head -1 | sed -e ';.*-on-;;')
    backfile="$rmtdir/DiffBackup..$hostname..$fixedfs-on-$daystr.cpio"
    echo "fbdate = $fbdate"
    echo "backfile = $backfile"
    if ! echo "(cd $fs; hfspax -T $fbdate $hfspaxarg .) | ncftpput $ncftparg $backfile)"; then
    fi
done


