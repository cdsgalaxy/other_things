#!/bin/bash

fs="/Users/car and another"
fs="/Users/car"

hostname="laptop"

bkupdir="/Backups"
bkupdir="."

rmtdir="/nersc/projects/ccse/$hostname"

errlog="-d $bkupdir/errorlog/ncftpput.errlog"
daystr=$(date +"%Y-%m-%d")

hfspaxarg="-wx cpio"
ncftparg="$errlog -W 'site setcos 7' -f $bkupdir/afiletest -c"
ncftparg="$errlog -f $bkupdir/afiletest -c"

for fs in $fs; do
    fixedfs=$(echo $fs | sed -e 's;/;_;g')
    daystr=$(date +"%y%m%d%H%M")
    tsfile="$bkupdir/timestamps/TimeStamp-for-$fixedfs-on-$daystr"
    backfile="$rmtdir/FullBackup..$hostname..$fixedfs-on-$daystr.hfspax"
    echo "tsfile =  $tsfile"
    echo "touch $tsfile"
    if ! echo "(cd $fs; hfspax $hfspaxarg .)| ncftpput $ncftparg $backfile"; then
	echo "rm %tsfile"
    fi
done

