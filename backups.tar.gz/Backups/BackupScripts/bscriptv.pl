#!/usr/bin/perl -w

# user configuration:

$arch_sys = "archive.nersc.gov";
#$arch_sys = "hpss.nersc.gov";
$arch_id = "vince";
$arch_pw = "XXXXXX";

# file systems to backup
#@fs = qw( /boot / );
@fs = qw( /var/tmp/vince/btest/incrtest );

#######################################################################
# must type as root first:  ??
# rpm -ivh /d/gigan/tmp/RPMS/powertools7.1/i386/perl-libnet-1.0703-5.i386.rpm
# TODO:
#   use -f for file username and password 
#   Test incremental
#   Test restore for large files (cpio --only-verify-crc)
#   Verify owner and times are restored properly.
#   Eliminate files that are too old.
#######################################################################

use Cwd;
$bkupdir = getcwd();

($day, $month, $year, $wday) = (localtime)[3..6];

@days = qw( Sun Mon Tue Wed Thu Fri Sat );
@months = qw ( Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec );

$daystr = "$day-$months[$month]-" . (1900+$year);

chop($hostname = `hostname`);

$incremental = 9;
#$incremental = 0;

$bTypeStr = "FullBackup";
if ( $incremental ) {
  $bTypeStr = "IncrBackup";
}

$findarg = ". -mount";

$prefix="$incremental-$daystr";

foreach $fs (@fs) {
    my $fixedfs = $fs;
    $fixedfs =~ s#/#_#g;
    my $tfile = "$bkupdir/FullBackupTimeStampFile-for-$fixedfs-on-$daystr";
    my $tfilename = "$bTypeStr..$hostname..$fixedfs-on-$daystr.cpio";
    $fixedfs = $prefix . $fixedfs . "_";
#   print "doing $fs\n";
    print "tfile =  $tfile\n";
#   print "tfilename =  $tfilename\n";
    unless ( $incremental ) {
        system("touch $tfile") == 0			or die "touch";
    }
    if ( $incremental ) {
        $findarg = $findarg . " -newer $tfile";
    }
#   print  ("(cd $fs; find $findarg | cpio -o -H crc) | split --bytes 1024m - ${fixedfs}\n");

    system ("(cd $fs; find $findarg | cpio -o -Hcrc 2>/dev/null) | ncftpput -E -d ncftpput.errlog -m -c -u $arch_id $arch_sys $tfilename") == 0						
 							or die "system";
}

