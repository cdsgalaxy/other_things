--------------------------------------------------------------------------
  instructions for using the windows backup scripts.
--------------------------------------------------------------------------
--------------------------------------------------------------------------
  files:  WindowsDiffBackup.cmd  -- for differential backups
          WindowsFullBackup.cmd  -- for full backups
--------------------------------------------------------------------------

you can run these scripts manually or set them as scheduled
tasks in windows.  the scripts first run ntbackup to create
backup files locally, then ftp the backup files to hpss (archive).

copy these scripts to a directory on your windows machine.
edit the copies as follows (don't check the changes back into cvs).

  set ftparch to your hpss server (archive.nerscc.gov or hpss.nersc.gov)
  set ftpacct=yourhpssusername
  set ftppass=yourhpsspassword (acct/pass are the same on hpss and archive)
  set bkpfldr to the location for the temporary backup files.
  - comment out and uncomment the WINNT or WINDOWS line (use only one), WINNT=w2k, WINDOWS=XP
  encrypt the folder containing these scripts (check the option
    to also encrypt files and subdirectories).

to run manually, double click the appropriate file.
to schedule backups, use the control panel:scheduled tasks tool.

the scripts do not delete the temporary files, so delete these
  after confirming the files were sent to hpss/archive.

you can exclude files by running ntbackup, then going to
  Tools:Options...:Exclude Files 

to recover files, ftp the backup file to a local drive and
  use ntbackup.

props:  chuck wrote these scripts.
