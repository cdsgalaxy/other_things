--------------------------------------------------------------------------
  instructions for using the linux backup scripts.
--------------------------------------------------------------------------
--------------------------------------------------------------------------
  files:  LinuxReadMe.txt            -- this file
          LinuxFullBackup.pl         -- perl script for making a full backup
	  LinuxDiffBackup.cmd        -- perl script for differential backups
	  LinuxFullBackupDirSys.cmd  -- another perl script for full backups
	                                (see details below)
--------------------------------------------------------------------------

--------------------------------------------------------------------------
  backups
--------------------------------------------------------------------------
the script chain is:  find | cpio | ncftpput
ncftpput must support the -c option (stdin).
no local backup file is created and there is no file size limitation
  for the backup file on hpss/archive.

copy these scripts to a directory on your linux machine.
edit the copies as follows (don't check the changes back into cvs).

  set $arch_sys to your hpss server (archive.nerscc.gov or hpss.nersc.gov)
  set $arch_id=yourhpssusername
  don't set $arch_pw
  set @fs to each directory you want backed up

-- create file for username/passwd

  encrypt the password file

run manually as root.


--------------------------------------------------------------------------
  -- full backups
--------------------------------------------------------------------------
files of the form:

  FullBackup..gigan.lbl.gov.._dirname-on-11-Dec-2001.cpio

will be created on hpss/archive, one file for each directory
specified in @fs


files of the form:

  FullBackupTimeStampFile-for-_dirname-on-11-Dec-2001

will be created in the directory where the backup script is run,
one file for each directory specified in @fs.



--------------------------------------------------------------------------
  -- differential backups
--------------------------------------------------------------------------
a file of the form:

  DiffBackup..gigan.lbl.gov.._dirname-on-11-Dec-2001.cpio

will be created on hpss/archive, one file for each directory
specified in @fs




--------------------------------------------------------------------------
  recovery
--------------------------------------------------------------------------
ncftpget must support the -c option.



props:  chuck wrote the first versions of these scripts (the hard part).
