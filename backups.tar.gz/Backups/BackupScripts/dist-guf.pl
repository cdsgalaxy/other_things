#!/usr/bin/perl -w

# user configuration:

$arch_sys = "archive.nersc.gov";
$arch_id = "XXX";
$arch_pw = "XXXXXX";

# file systems to backup
#@fs = qw( /boot / );
@fs = qw( /boot );

#######################################################################
#
# must type as root first:
# rpm -ivh /d/gigan/tmp/RPMS/powertools7.1/i386/perl-libnet-1.0703-5.i386.rpm
# TODO:
# Eliminate files that are too old.

use Cwd;
$bkupdir = getcwd();

($day, $month, $year, $wday) = (localtime)[3..6];

@days = qw( Sun Mon Tue Wed Thu Fri Sat );
@months = qw ( Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec );

$daystr = "$day-$months[$month]-" . (1900+$year);


chop($hostname = `hostname`);

$incremental = 9;

use Net::FTP;

$ftp = Net::FTP->new($arch_sys, Debug => 0)	or die "ftp";
$ftp->login( $arch_id, $arch_pw)		or die "login";
$ftp->binary()						or die "binary";
$ftp->mkdir("$hostname");
$ftp->cwd("$hostname")					or die "cwd";

if ( $incremental ) {
    $ftp->mkdir("$days[$wday]");
    $ftp->cwd("$days[$wday]")				or die "cwd 2";
}

$findarg = ". -mount";

$prefix="$incremental-$daystr";

foreach $fs (@fs) {
    my $fixedfs = $fs;
    $fixedfs =~ s#/#_#g;
    my $tfile = "$bkupdir/full-backup-of-$fixedfs-on-$daystr";
    $fixedfs = $prefix . $fixedfs . "_";
#   print "doing $fs\n";
    unless ( $incremental ) {
	system("touch $tfile") == 0			or die "touch";
    }
    if ( $incremental ) {
        $findarg = $findarg . " -newer $tfile";
    }
#   print  ("(cd $fs; find $findarg | cpio -o -H crc) | split --bytes 1024m - ${fixedfs}\n");
    system ("(cd $fs; find $findarg | cpio -o -Hcrc 2>/dev/null) | split -b 1000k - ${fixedfs}") == 0						
							or die "system";
    
    @files=glob("${fixedfs}*");

#   print "files are @files\n";

    foreach $file (@files) {
#       print "doing $file\n";
        $ftp->put($file) && unlink($file) 		or warn "fail $file";
    }  
}
$ftp->quit();
