#!/usr/bin/perl -w

$arch_sys = "archive.nersc.gov";
#$arch_sys = "hpss.nersc.gov";
$arch_id = "vince";
$arch_pw = "XXXXXX";
$rdestdir = ".";
$rfilename = "IncrBackup..gigan.lbl.gov.._var_tmp_vince_btest_inctest-on-12-Dec-2001.cpio";

#######################################################################
# ncftpget -E -u vince hpss.nersc.gov . sctest.cpio
#######################################################################
# TODO:
#   use -f for file username and password 
#   Test incremental
#   Test restore for large files (cpio --only-verify-crc)
#######################################################################

use Cwd;
$bkupdir = getcwd();

($day, $month, $year, $wday) = (localtime)[3..6];

system ("ncftpget -c -E -u $arch_id $arch_sys $rdestdir $rfilename | cpio -i )") == 0						
 							or die "system";
    

