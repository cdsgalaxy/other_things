#******************************************************
# This is the gloabl variable list that will be used by 
# all the scripts in this directory. Since the scripts 
# are both very simialiar in both code and access methods
# it is easiest if we just have a chental location for the 
# variables
#******************************************************
#
#*******************************************************************$
# In this section we are going to set some variables that are unique$
# to the users enviroment$
#$
# user configurations:$
# 1) $arch_sys = "which machine the backups are sent to"$
# 2) @fs = qw( which partions do you want backed up?)$
# 3) $dirpath = "this is the path to your backups on the backup machine" $
#******************************************************************$

$arch_sys = "archive.nersc.gov";
@fs = qw( / /boot /usr /export /tmp /var );
$dirpath = "/home/a/your backup dir";
1;
