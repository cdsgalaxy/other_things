#******************************************************8
# This is the gloabal variable list that will be used by 
# all the scripts in this directory. Since the scripts 
# are both very simialiar in both code and access methods
#it is easiest if we just have a chental location for the 
# variables
#******************************************************
#
#*******************************************************************$
# In this section we are going to set some variables that are unique$
# to the users enviroment$
#$
# user configurations:$
# 1)  $arch_sys = "which machine the backups are sent to"$
# 2)  @fs = qw( which partions do you want backed up?)$
# 3)  $dirpath = "this is the path to your backups on the backup machine" $
# 4)  $servicelvl = "Defines the level of service for HPSS" $
# 5)  $bkupweeks = "this defines the week number when backups are trashed"$
# 6)  $emailtarget = "The address to which the error messages will be emailed"$
# 7)  $emailsender = "The sender of the error-messaged emails"$
# 8)  $username = "The username that corresponds to $arch_sys$
# 9)  $password = "The password corresponding to the given $
#******************************************************************$


$arch_sys = "hpss.nersc.gov";
@fs = qw( /export );
$dirpath = "/home/a/anagbkup";
$servicelvl = 7;
$bkupweeks = 7;
$emailtarget = "gdsmith\@lbl.gov";  #Change this.  Remember "\" before the "@".
$emailsender = "gdsmith\@lbl.gov"; #Change this.  "                         "
$username = "";
$password = "";
